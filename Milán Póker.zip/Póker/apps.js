console.log("meow")

let kartya = [
    "A-C",
    "2-C",
    "3-C",
    "4-C",
    "5-C",
    "6-C",
    "7-C",
    "8-C",
    "9-C",
    "10-C",
    "J-C",
    "Q-C",
    "K-C",
    "A-D",
    "2-D",
    "3-D",
    "4-D",
    "5-D",
    "6-D",
    "7-D",
    "8-D",
    "9-D",
    "10-D",
    "J-D",
    "Q-D",
    "K-D",
    "A-H",
    "2-H",
    "3-H",
    "4-H",
    "5-H",
    "6-H",
    "7-H",
    "8-H",
    "9-H",
    "10-H",
    "J-H",
    "Q-H",
    "K-H",
    "A-S",
    "2-S",
    "3-S",
    "4-S",
    "5-S",
    "6-S",
    "7-S",
    "8-S",
    "9-S",
    "1-S",
    "J-S",
    "Q-S",
    "K-S",
];
function c_create(number1, number2, kinekaköre) {
    let card = document.createElement("img");
    card.src = "Forrás/" + number2 + "-" + number1 + ".png";
    card.title = number1 + "_" + number2;
    card.alt = number1 + "_" + number2;
    card.id = number1 + "_" + number2;
    card.classList = "cards";
    document.getElementById(kinekaköre).appendChild(card); //document.getElementById helyére annak a halmaznak az id-ét kell beírni, ahová beakarjuk illeszteni a kártyát.
}

/*
var jatekosertek = 0;

if (x === 10 && x === "J" && x === "Q" && x === "K" && x === "A" && )
{
    jatekosertek++;
}

function kartyaszamit()

jatekos[i][1] == 1 && jatekos[i][4] == "S"


if(jatekos[i] == "1-S" && jatekos[i+1] == "J-S" && jatekos[i+2] == "Q-S" && jatekos[i+3] == "K-S" && jatekos[i] == "A-S")
{

}

var c_symbol = false
var d_symbol = false
var h_symbol = false
var s_symbol = false

if(jatekos[i][3] == "C" && jatekos[i+1][3] == "C" && jatekos[i+2][3] == "C" && jatekos[i+3][3] == "C" && jatekos[i+4][3] == "C")
{
    c_symbol = true
}
else if(jatekos[i][3] == "D" && jatekos[i+1][3] == "D" && jatekos[i+2][3] == "D" && jatekos[i+3][3] == "D" && jatekos[i+4][3] == "D")
{
    d_symbol = true
}
else if(jatekos[i][3] == "H" && jatekos[i+1][3] == "H" && jatekos[i+2][3] == "H" && jatekos[i+3][3] == "H" && jatekos[i+4][3] == "H")
{
    h_symbol = true
}
else if(jatekos[i][3] == "S" && jatekos[i+1][3] == "S" && jatekos[i+2][3] == "S" && jatekos[i+3][3] == "S" && jatekos[i+4][3] == "S")
{
    s_symbol = true
}

if((c_symbol == true || d_symbol == true || h_symbol == true || s_symbol == true) && jatekos[i][1] == 1 && jatekos[i+1][1] == "J" && jatekos[i+2][1] == "Q" && jatekos[i+3][1] == "K" && jatekos[i+4][1] == "A")
{

}
*/

var symbol = false
var straight = false

function flush(symbol)
{
    if((jatekos[i][3] == "C" && jatekos[i+1][3] == "C" && jatekos[i+2][3] == "C" && jatekos[i+3][3] == "C" && jatekos[i+4][3] == "C") || (jatekos[i][3] == "D" && jatekos[i+1][3] == "D" && jatekos[i+2][3] == "D" && jatekos[i+3][3] == "D" && jatekos[i+4][3] == "D") || (jatekos[i][3] == "H" && jatekos[i+1][3] == "H" && jatekos[i+2][3] == "H" && jatekos[i+3][3] == "H" && jatekos[i+4][3] == "H") || (jatekos[i][3] == "S" && jatekos[i+1][3] == "S" && jatekos[i+2][3] == "S" && jatekos[i+3][3] == "S" && jatekos[i+4][3] == "S"))
    {
        symbol = true
    }

    return symbol
}

function straight(straight)
{
    if(jatekos[i][1] == )
}